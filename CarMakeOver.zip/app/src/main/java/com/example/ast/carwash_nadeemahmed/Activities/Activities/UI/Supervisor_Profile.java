package com.example.ast.carwash_nadeemahmed.Activities.Activities.UI;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.ast.carwash_nadeemahmed.R;

/**
 * Created by AST on 9/15/2017.
 */

public class Supervisor_Profile extends android.support.v4.app.Fragment {




    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.supervisor_profile,null);





        return view;
    }
}
