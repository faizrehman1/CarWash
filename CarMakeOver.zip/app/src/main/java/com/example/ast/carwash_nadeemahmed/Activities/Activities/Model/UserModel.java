package com.example.ast.carwash_nadeemahmed.Activities.Activities.Model;

/**
 * Created by AST on 9/28/2017.
 */

public class UserModel {

    public String fname;
    public String lname;
    public String email;
    public String passs;
    public String address;
    public String UID;
    public String imageUrl;


    public UserModel() {
    }

    public UserModel(String fname, String lname, String email, String passs, String address, String UID, String imageUrl) {
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.passs = passs;
        this.address = address;
        this.UID = UID;
        this.imageUrl = imageUrl;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasss() {
        return passs;
    }

    public void setPasss(String passs) {
        this.passs = passs;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public static UserModel myObj;
    public static UserModel getInstance(String fname, String lname, String email, String passs, String address, String UID, String imageUrl){
        if(myObj == null){
            myObj = new UserModel(fname, lname,email,passs,address,UID,imageUrl);
        }
        return myObj;
    }
}
